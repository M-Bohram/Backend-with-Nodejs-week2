// TASK 3: Update the routers

const express = require('express');
// TODO: Import the model

const promotionRouter = express.Router();


promotionRouter.route('/')
.get((req, res, next) => {
    // TODO: Use the model to fetch or find all promotions documents
})
.post((req, res, next) => {
    // TODO: Use the model to create a promotion document
})
.put((req, res) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /promotions');
})
.delete((req, res, next) => {
    // TODO: Use the model to delete all promotions documents
});


promotionRouter.route('/:promotionId')
.get((req, res, next) => {
    // TODO: Use the model to fetch the promotion document with promotionId as the ID
})
.post((req, res) => {
    res.statusCode = 403;
    res.end(`POST operation not supported on /campsites/${req.params.campsiteId}`);
})
.put((req, res, next) => {
    // TODO: Use the model to update the promotion document with promotionId as the ID
})
.delete((req, res, next) => {
    // TODO: Use the model to delete the promotion document with promotionId as the ID
});

module.exports = promotionRouter;