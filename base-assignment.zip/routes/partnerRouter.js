// TASK 3: Update the routers

const express = require('express');
// TODO: Import the model

const partnerRouter = express.Router();


partnerRouter.route('/')
.get((req, res, next) => {
    // TODO: Use the model to fetch or find all partners documents
})
.post((req, res, next) => {
    // TODO: Use the model to create a partner document
})
.put((req, res) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /partners');
})
.delete((req, res, next) => {
    // TODO: Use the model to delete all partners documents
});


partnerRouter.route('/:partnerId')
.get((req, res, next) => {
    // TODO: Use the model to fetch the partner document with partnerId as the ID
})
.post((req, res) => {
    res.statusCode = 403;
    res.end(`POST operation not supported on /campsites/${req.params.campsiteId}`);
})
.put((req, res, next) => {
    // TODO: Use the model to update the partner document with partnerId as the ID
})
.delete((req, res, next) => {
    // TODO: Use the model to delete the partner document with partnerId as the ID
});

module.exports = partnerRouter;