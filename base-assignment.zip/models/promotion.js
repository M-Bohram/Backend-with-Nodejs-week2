// TASK 2: Create a Schema and Model for Promotions

// TODO: Create the Schema for Promotion
// Use the sample document to create the Schema:
// {
//     "name": "Mountain Adventure",
//     "image": "images/breadcrumb-trail.jpg",
//     "featured": true,
//     "cost": 1299,
//     "description": "Book a 5-day mountain trek with a seasoned outdoor guide! Fly fishing equipment and lessons provided."
// }




// TODO: Create the Model from the above Schema
// TODO: Export the Model