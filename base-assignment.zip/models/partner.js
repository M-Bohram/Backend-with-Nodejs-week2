// TASK 1: Create a Schema and Model for Partners

// TODO: Create the Schema for Partner
// Use the sample document to create the Schema:
// {
//     "name": "Mongo Fly Shop",
//     "image": "images/mongo-logo.png",
//     "featured": false,
//     "description": "Need a new fishing pole, a tacklebox, or flies of all kinds? Stop by Mongo Fly Shop."
// }




// TODO: Create the Model from the above Schema
// TODO: Export the Model